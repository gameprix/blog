GamePrix - Paket 30 Artikel HTML
==================================
Isi:
- 1 artikel penuh (article_01_full_team_battle_royale.html) — panjang ~2600 kata, siap publish.
- 29 file template (article_02_template.html ... article_30_template.html) — setiap file berisi struktur SEO, CSS, JS, dan ilustrasi SVG. Silakan kembangkan konten menjadi 2.500-5.000 kata sesuai kebutuhan.

Semua file sudah mengandung:
- Skrip Google Tag (gtag.js) dan Google AdSense yang Anda minta.
- Meta verification dan amp-auto-ads.
- CSS & JS terbenam untuk tampilan responsif, read-time, dan tombol share.
- Ilustrasi SVG inline (bebas hak cipta karena dihasilkan vektor sederhana).

Cara pakai:
- Extract zip, upload file HTML ke https://gameprix.github.io/blog/ atau tempat hosting Anda.
- Untuk menambah gambar raster, ganti atau tambahkan <img> di dalam artikel dengan file gambar di folder yang sama.

Catatan:
- Hanya article_01_full_* yang sudah ditulis panjang (~2600 kata). 29 template siap dikembangkan menjadi panjang 2500-5000 kata masing-masing. Jika Anda ingin, saya dapat membantu memperpanjang template tertentu menjadi panjang penuh.

Terima kasih. - GamePrix Auto-Generator
